package io.github.rumangerst.smithyoverhaul;

import io.github.rumangerst.spigot.nbtapi.SpigotNBT;
import org.bukkit.Material;
import org.bukkit.craftbukkit.v1_8_R3.inventory.CraftFurnaceRecipe;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.PluginLogger;
import org.bukkit.plugin.java.JavaPlugin;

public class SmithyOverhaulPlugin extends JavaPlugin implements Listener
{    
    public static PluginLogger LOGGER = null;    
    private TieredSmity smity = new TieredSmity();
    
    public SmithyOverhaulPlugin()
    {
        LOGGER = new PluginLogger(this);
    }
    
    @Override
    public void onEnable()
    {
        /*MinecraftForge.EVENT_BUS.register(eventHandler);
        MinecraftForge.EVENT_BUS.register(smity);*/
        
        TieredTool.InitializeTieredTools();
        
        /*GameRegistry.addSmelting(new ItemStack(Items.iron_pickaxe), new ItemStack(Items.iron_ingot, 2), 0);
        GameRegistry.addSmelting(new ItemStack(Items.iron_shovel), new ItemStack(Items.iron_ingot, 1), 0);
        GameRegistry.addSmelting(new ItemStack(Items.iron_hoe), new ItemStack(Items.iron_ingot, 1), 0);
        GameRegistry.addSmelting(new ItemStack(Items.iron_axe), new ItemStack(Items.iron_ingot, 2), 0);
        GameRegistry.addSmelting(Items.coal, new ItemStack(Blocks.gravel, 1).setStackDisplayName("Asche"), 0);        */
        
        createFurnaceCoalSmelting();
        
        getServer().getPluginManager().registerEvents(this, this);
        getServer().getPluginManager().registerEvents(smity, this);
              
    }
    
    private void createFurnaceCoalSmelting()
    {
        ItemStack src = new ItemStack(Material.COAL);
        ItemStack dst = new ItemStack(Material.GRAVEL);        
        SpigotNBT.setString(dst, "display/Name", "Asche");
        
        getServer().addRecipe(new CraftFurnaceRecipe(dst, src));
    }
    
    @Override
    public void onDisable()
    {
        
    }
    
    @EventHandler
    public void useTieredToolEvent(PlayerInteractEvent event)
    {
        if(!event.isCancelled() && event.getAction() == Action.LEFT_CLICK_BLOCK && event.hasItem())
        {
            TieredTool.applyToolToPlayer(event.getPlayer());
        }
    }
    
    @EventHandler
    public void disableRepairRecipe(PrepareItemCraftEvent event)
    {
        if(event.isRepair())
            event.getInventory().setResult(new ItemStack(Material.AIR));
    }
}
