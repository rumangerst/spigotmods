/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package io.github.rumangerst.smithyoverhaul;

import io.github.rumangerst.spigot.nbtapi.SpigotNBT;
import io.github.rumangerst.smithyoverhaul.tooleffects.ITieredToolEffect;
import io.github.rumangerst.smithyoverhaul.tooleffects.TieredToolCraftedPickaxeEffect;
import io.github.rumangerst.smithyoverhaul.tooleffects.TieredToolDamageEffect;
import io.github.rumangerst.smithyoverhaul.tooleffects.TieredToolEnchantEffect;
import io.github.rumangerst.smithyoverhaul.tooleffects.TieredToolPotionEffect;
import java.util.ArrayList;
import java.util.HashMap;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffectType;
 

/**
 *
 * @author ruman
 */
public class TieredTool
{    
    public static ArrayList<String> TieredToolsIDs = new ArrayList<>();
    public static HashMap<String, TieredTool> TieredTools = new HashMap<>();
    public static HashMap<String, TieredTool> TieredToolsByName = new HashMap<>();
    public static HashMap<Material, TieredTool> DefaultTools = new HashMap<>();
    
    private String id;
    private String name;    
    private String[] lore;
    private Material toolitem; 
    private ITieredToolEffect[] effects;
    
    private TieredTool()
    {
        
    }
    
    public String getId()
    {
        return id;
    }
    
    public String getName()
    {
        return name;        
    }
    
    public String[] getLore()
    {
        return lore;
    }
    
    public Material getToolItem()
    {
        return toolitem;
    }
    
    public ITieredToolEffect[] getEffects()
    {
        return effects;
    }
    
    private static void AddTieredTool(Material item, String id, String name, String lore, ITieredToolEffect ... effects)
    {
        TieredTool tool = new TieredTool();
        
        tool.toolitem = item;
        tool.id = id;
        tool.name = name;
        tool.lore = lore.split("\n");
        tool.effects = effects;
        
        TieredTools.put(id, tool);
        TieredToolsByName.put(name, tool);
        TieredToolsIDs.add(id);
    }
    
    private static void AddTieredTool(Material item, String id, String name, ITieredToolEffect ... effects)
    {
        AddTieredTool(item,id, name, "", effects);
    }
    
    public static void setItemTieredToolId(ItemStack stack, String value)
    {
        SpigotNBT.setString(stack, "tieredtoolid", value);
    }
    
    public static void setItemStackName(ItemStack stack, String value)
    {
        SpigotNBT.setString(stack, "display/Name", value);
    }
    
    public static void setItemStackLore(ItemStack stack, String ... value)
    { 
        SpigotNBT.setStringList(stack, "display/Lore", value);
    }
    
    public void applyToStack(ItemStack stack)
    {
        setItemStackName(stack, name);
        setItemStackLore(stack, lore);
        SpigotNBT.setString(stack, "tieredtoolid", id);
        
        /*FMLLog.info("Applying TieredTool ...");
        
        NBTTagCompound nbt = new NBTTagCompound();
        nbt.setString("tieredtoolid", id);       
        
        stack.setTagCompound(nbt);
        
        NBTTagCompound display = new NBTTagCompound();        
        display.setString("Name", name);
        
        NBTTagList nbtlore = new NBTTagList();
        
        for(String t : lore)
        {
            nbtlore.appendTag(new NBTTagString(t));
        }
        
        display.setTag("Lore", nbtlore);        
        nbt.setTag("display", display);*/
        
        //stack.setStackDisplayName(name);
    }
    
    public ItemStack makeStack()
    {
        ItemStack stack = new ItemStack(toolitem);        
        applyToStack(stack); 
        return stack;
    }
    
    public void applyToPlayer(Player player)
    {
        for(ITieredToolEffect effect : effects)
        {
            effect.applyToPlayer(player);
        }
    }
    
    public static boolean giveToPlayer(String id, Player player)
    {
        if(TieredTools.containsKey(id))
        {
            player.getInventory().addItem(TieredTools.get(id).makeStack());
            
            return true;
        }
        
        return false;
    }
    
    public static void sendItemList(CommandSender sender)
    {
        for(String key : TieredToolsIDs)
        {
            sender.sendMessage(key + ": " + TieredTools.get(key).name);
        }
    }
    
    public static void InitializeTieredTools()
    {   
        // override tier (wood + stone)
        AddTieredTool(Material.WOOD_PICKAXE, "woodenpickaxe", "Spielzeug-Spitzhacke", new TieredToolDamageEffect(59));
        AddTieredTool(Material.STONE_PICKAXE, "stonepickaxe", "Spielzeug-Spitzhacke", new TieredToolDamageEffect(131));
        
        // Crafting 
        AddTieredTool(Material.IRON_PICKAXE, "unfinishedironpickaxe", "Unfertige Eisenspitzhacke", new TieredToolPotionEffect(PotionEffectType.SLOW_DIGGING, 5.0, 10));
        AddTieredTool(Material.IRON_PICKAXE, "craftedironpickaxe", "Geschmiedete Eisenspitzhacke", new TieredToolCraftedPickaxeEffect());
        AddTieredTool(Material.IRON_SPADE, "unfinishedironshovel", "Unfertige Eisenschaufel", new TieredToolPotionEffect(PotionEffectType.SLOW_DIGGING, 5.0, 10));
        AddTieredTool(Material.IRON_SPADE, "craftedironshovel", "Geschmiedete Eisenschaufel", new TieredToolCraftedPickaxeEffect());
        AddTieredTool(Material.IRON_AXE, "unfinishedironaxe", "Unfertige Eisenaxt", new TieredToolPotionEffect(PotionEffectType.SLOW_DIGGING, 5.0, 10));
        AddTieredTool(Material.IRON_AXE, "craftedironaxe", "Geschmiedete Eisenaxt", new TieredToolCraftedPickaxeEffect());
        AddTieredTool(Material.IRON_HOE, "unfinishedironhoe", "Unfertige Eisenhacke", new TieredToolPotionEffect(PotionEffectType.SLOW_DIGGING, 5.0, 10));
        AddTieredTool(Material.IRON_HOE, "craftedironhoe", "Geschmiedete Eisenhacke", new TieredToolCraftedPickaxeEffect());
        
        /*// Iron (Human) tier
        AddTieredTool(Material.IRON_PICKAXE, "oldironpickaxe", "Alte Eisenspitzhacke", new TieredToolPotionEffect(Potion.digSlowdown, 5.0, 3));
        AddTieredTool(Material.IRON_PICKAXE, "crudeironpickaxe", "Rohe Eisenspitzhacke", new TieredToolPotionEffect(Potion.digSlowdown, 3.0, 2));
        AddTieredTool(Material.IRON_PICKAXE, "improvedironpickaxe", "Verbesserte Eisenspitzhacke", new TieredToolPotionEffect(Potion.digSlowdown, 3.0, 1));
        AddTieredTool(Material.IRON_PICKAXE, "strongironpickaxe", "Verstärkte Eisenspitzhacke");
        AddTieredTool(Material.IRON_PICKAXE, "craftsmenironpickaxe", "Handwerker Eisenspitzhacke", "Eine ordentliche Spitzhacke",
                new TieredToolEnchantEffect(Enchantment.efficiency, 1));
        AddTieredTool(Material.IRON_PICKAXE, "masterironpickaxe", "Meisterliche Eisenspitzhacke", "Von einem wahren Meister geschaffen",
                new TieredToolEnchantEffect(Enchantment.efficiency, 2),
                new TieredToolEnchantEffect(Enchantment.unbreaking, 1));
        AddTieredTool(Material.IRON_PICKAXE, "grandmasterironpickaxe", "Großmeisterliche Eisenspitzhacke", "Von einem wahren Meister geschaffen",
                new TieredToolEnchantEffect(Enchantment.efficiency, 3),
                new TieredToolEnchantEffect(Enchantment.unbreaking, 3));
        
        // Magic tier (Human)
        AddTieredTool(Material.IRON_PICKAXE, "enchantedmasterironpickaxe", "Verzauberte Meisterliche Eisenspitzhacke", "Die Menschen versuchten die Eigenschaften der Elfenwerkzeuge nachzumachen\nEs gibt noch ein Rest menschlicher Magie",
                new TieredToolEnchantEffect(Enchantment.efficiency, 2),
                new TieredToolEnchantEffect(Enchantment.unbreaking, 1),
                new TieredToolPotionEffect(Potion.regeneration, 1.0, 1));
        AddTieredTool(Material.IRON_PICKAXE, "enchantedgrandmasterironpickaxe", "Verzauberte Meisterliche Eisenspitzhacke", "Die Menschen versuchten die Eigenschaften der Elfenwerkzeuge nachzumachen\nEs gibt noch ein Rest menschlicher Magie",
                new TieredToolEnchantEffect(Enchantment.efficiency, 3),
                new TieredToolEnchantEffect(Enchantment.unbreaking, 3),
                new TieredToolPotionEffect(Potion.regeneration, 1.0, 1));
        AddTieredTool(Material.IRON_PICKAXE, "weakvioletorderpickaxe", "Spitzhacke mit Siegeln des Violetten Ordens", "Es gibt noch einen Rest Magie des Violetten Ordens", 
                new TieredToolPotionEffect(Potion.hunger, 5.0, 1),                
                new TieredToolEnchantEffect(Enchantment.fortune, 1));
        AddTieredTool(Material.IRON_PICKAXE, "evilvioletorderpickaxe", "Spitzhacke mit Siegeln des Violetten Ordens", "Etwas stimmt mit dieser Spitzhacke nicht", 
                new TieredToolPotionEffect(Potion.wither, 5.0, 1),                
                new TieredToolEnchantEffect(Enchantment.fortune, 4).add(Enchantment.unbreaking, 6));
        AddTieredTool(Material.IRON_PICKAXE, "blackorderpickaxe", "Spitzhacke mit Siegeln des Hohen Ordens", "Der Hohe Orden der Magie hat dieses Werkzeug verzaubert",                
                new TieredToolPotionEffect(Potion.blindness, 5.0, 2), 
                new TieredToolPotionEffect(Potion.hunger, 10.0, 1),
                new TieredToolPotionEffect(Potion.digSpeed, 5.0, 3),
                new TieredToolEnchantEffect(Enchantment.fortune, 3));
        
        // Gold (Elven) tier        
        AddTieredTool(Material.GOLD_PICKAXE, "oldelvenpickaxe", "Alte Elfenspitzhacke", "Alle Magie ist bereits aus diesem Werkzeug gewichen", 
                new TieredToolPotionEffect(Potion.digSlowdown, 3.0, 1));
        AddTieredTool(Material.GOLD_PICKAXE, "weakelvenpickaxe", "Verbrauchte Elfenspitzhacke", "Es ist noch ein Rest der elfischen Regenerationsmagie vorhanden", 
                new TieredToolPotionEffect(Potion.regeneration, 1.0, 1));
        AddTieredTool(Material.GOLD_PICKAXE, "magicelvenpickaxe", "Magische Elfenspitzhacke", "Die Elfen benutzen magisch verbesserte Spitzhacken",
                new TieredToolPotionEffect(Potion.regeneration, 1.0, 1), 
                new TieredToolPotionEffect(Potion.digSpeed, 1.0, 1),
                new TieredToolEnchantEffect(Enchantment.unbreaking, 1));
        AddTieredTool(Material.GOLD_PICKAXE, "starvingelvenpickaxe", "Auszehrende Elfenspitzhacke", "Dieses Werkzeug wurde anscheinend für Elfen entworfen\nDie starke Magie schädigt alle anderen Rassen",
                new TieredToolPotionEffect(Potion.confusion, 10.0, 2), 
                new TieredToolPotionEffect(Potion.poison, 5.0, 1),
                new TieredToolPotionEffect(Potion.digSpeed, 5.0, 3),
                new TieredToolEnchantEffect(Enchantment.fortune, 1));
        AddTieredTool(Material.GOLD_PICKAXE, "cursedelvenpickaxe", "Auszehrende Elfenspitzhacke", "Dieses Werkzeug wurde anscheinend für Elfen entworfen\nDie starke Magie schädigt alle anderen Rassen",
                new TieredToolPotionEffect(Potion.confusion, 15.0, 2), 
                new TieredToolPotionEffect(Potion.blindness, 5.0, 2), 
                new TieredToolPotionEffect(Potion.poison, 10.0, 1),
                new TieredToolPotionEffect(Potion.digSpeed, 5.0, 3),
                new TieredToolEnchantEffect(Enchantment.fortune, 3));
        
        // Diamond (Dwarven) tier
        AddTieredTool(Material.IRON_PICKAXE, "olddwarwenmetalpickaxe", "Alte Zwergenspitzhacke", "Obwohl alt immer noch ein gutes Werkzeug",
                new TieredToolEnchantEffect(Enchantment.efficiency, 1));
        AddTieredTool(Material.IRON_PICKAXE, "dwarwenmetalpickaxe", "Zwergenspitzhacke", "Nur Zwerge sind in der Lage Metall so zu verarbeiten",
                new TieredToolEnchantEffect(Enchantment.efficiency, 2).add(Enchantment.unbreaking, 2));
        AddTieredTool(Material.DIAMOND_PICKAXE, "crudedwarwendiamondpickaxe", "Diamantene Zwergenspitzhacke", "Die Zwerge haben herausgefunden Diamanten als Material für Werkzeuge zu benutzen",
                new TieredToolEnchantEffect(Enchantment.efficiency, 2).add(Enchantment.unbreaking, 2));
        AddTieredTool(Items.diamond_pickaxe, "improveddwarwendiamondpickaxe", "Verbesserte Diamantene Zwergenspitzhacke", "Die Zwerge haben herausgefunden Diamanten als Material für Werkzeuge zu benutzen.\nSie konnten diese Technik weiter verfeinern",
                new TieredToolEnchantEffect(Enchantment.efficiency, 2).add(Enchantment.unbreaking, 3));
        AddTieredTool(Items.diamond_pickaxe, "moderndwarwendiamondpickaxe", "Moderne Diamantene Zwergenspitzhacke", "Selbst die Magier kennen kein Verfahren, um Materialien so zu bearbeiten",
                new TieredToolEnchantEffect(Enchantment.efficiency, 4).add(Enchantment.unbreaking, 5));*/
        
        //Define default tools
        DefaultTools.put(Material.IRON_PICKAXE, TieredTools.get("unfinishedironpickaxe"));
        DefaultTools.put(Material.IRON_AXE, TieredTools.get("unfinishedironaxe"));
        DefaultTools.put(Material.IRON_SPADE, TieredTools.get("unfinishedironshovel"));
        DefaultTools.put(Material.IRON_HOE, TieredTools.get("unfinishedironhoe"));
        
        DefaultTools.put(Material.GOLD_PICKAXE, TieredTools.get("oldgoldpickaxe"));
        DefaultTools.put(Material.DIAMOND_PICKAXE, TieredTools.get("crudedwarwendiamondpickaxe"));
        DefaultTools.put(Material.WOOD_PICKAXE, TieredTools.get("woodenpickaxe"));
        DefaultTools.put(Material.STONE_PICKAXE, TieredTools.get("stonepickaxe"));
    }
    
    public static void applyToolToPlayer(Player player)
    {
        if(player.getItemInHand() != null)
        {
            TieredTool tool = getTieredToolItem(player.getItemInHand()); 
            
            if(tool == null && DefaultTools.containsKey(player.getItemInHand().getType()))
            {
                //Default: Apply "old iron pickaxe"
                tool = DefaultTools.get(player.getItemInHand().getType());
            }
            
            if (tool != null)
            {
                if(!player.getItemInHand().getItemMeta().hasDisplayName())
                {                
                    //Rename tool if it does not have a name                        
                    tool.applyToStack(player.getItemInHand());
                }

                tool.applyToPlayer(player);
            }
        }
    }
    
    public static TieredTool getTieredToolItem(ItemStack stack)
    {
        if(stack != null && stack.getType() != Material.AIR)
        {
            String id = SpigotNBT.getString(stack, "tieredtoolid", "");
            
            if(!id.isEmpty())
            {
                return TieredTools.getOrDefault(id, null);
            }
        }
        
        return null;
    }
}
