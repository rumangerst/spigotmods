/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package io.github.rumangerst.smithyoverhaul.tooleffects;

import io.github.rumangerst.spigot.nbtapi.SpigotNBT;
import io.github.rumangerst.smithyoverhaul.TieredTool;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 *
 * @author ruman
 */
public class TieredToolCraftedPickaxeEffect implements ITieredToolEffect
{

    @Override
    public void applyToPlayer(Player player)
    {        
        
        if(TieredTool.getTieredToolItem(player.getItemInHand()) != null)
        {
            ItemStack stack = player.getItemInHand();
            
            double exhaustion = SpigotNBT.getDouble(stack, "craftedtieredtool/exhaustion", 0);
            double efficiency = SpigotNBT.getDouble(stack, "craftedtieredtool/efficiency", 0);
            
            if(exhaustion > 0.9)
                player.addPotionEffect(new PotionEffect(PotionEffectType.HUNGER, secondsToTicks(10), 2));
            else if(exhaustion > 0.8)
                player.addPotionEffect(new PotionEffect(PotionEffectType.HUNGER, secondsToTicks(5), 2));
            else if(exhaustion > 0.7)
                player.addPotionEffect(new PotionEffect(PotionEffectType.HUNGER, secondsToTicks(7), 1));
            else if(exhaustion > 0.6)
                player.addPotionEffect(new PotionEffect(PotionEffectType.HUNGER, secondsToTicks(5), 1));
            else if(exhaustion > 0.5)
                player.addPotionEffect(new PotionEffect(PotionEffectType.HUNGER, secondsToTicks(2), 1));
            
            if(efficiency < 0.1)
                player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_DIGGING, secondsToTicks(7), 2));
            else if(efficiency < 0.2)
                player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_DIGGING, secondsToTicks(5), 2));
            else if(efficiency < 0.3)
                player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_DIGGING, secondsToTicks(3), 1));
            else if(efficiency < 0.4)
                player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_DIGGING, secondsToTicks(2), 1));
            else if(efficiency < 0.5)
                player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_DIGGING, secondsToTicks(1), 1));
        }
    }
    
    private int secondsToTicks(double seconds)
    {
        return (int)(seconds * 1000.0 / 60.0);
    }
    
}
