/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package io.github.rumangerst.smithyoverhaul.tooleffects;

import io.github.rumangerst.smithyoverhaul.TieredTool;
import org.bukkit.entity.Player;

/**
 *
 * @author ruman
 */
public class TieredToolDamageEffect implements ITieredToolEffect
{
    public int damage;
    
    public TieredToolDamageEffect(int damage)
    {
        this.damage = damage;
    }

    @Override
    public void applyToPlayer(Player player)
    {
        if(TieredTool.getTieredToolItem(player.getItemInHand()) != null)
        {
            player.getItemInHand().setDurability((short)1);
        }
    }
}
