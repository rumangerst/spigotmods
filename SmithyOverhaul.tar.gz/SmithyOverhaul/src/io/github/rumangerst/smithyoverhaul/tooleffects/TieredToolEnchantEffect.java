/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package io.github.rumangerst.smithyoverhaul.tooleffects;

import io.github.rumangerst.smithyoverhaul.TieredTool;
import java.util.ArrayList;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;


/**
 *
 * @author ruman
 */
public class TieredToolEnchantEffect implements ITieredToolEffect
{
    
    public ArrayList<Enchantment> enchantments = new ArrayList<Enchantment>();
    public ArrayList<Integer> levels = new ArrayList<Integer>();
    
    public TieredToolEnchantEffect(Enchantment enchantment, int level)
    {        
        if(level < 0)
        {
            throw new IllegalArgumentException("Enchantment level cannot be negative");
        }
        
        enchantments.add(enchantment);
        levels.add(level);
    }
    
    public TieredToolEnchantEffect add(Enchantment enchantment, int level)
    {
        enchantments.add(enchantment);
        levels.add(level);
        
        return this;
    }

    @Override
    public void applyToPlayer(Player player)
    {
        ItemStack stack = player.getItemInHand();
        
        if(TieredTool.getTieredToolItem(stack) != null)
        {
            if(!stack.hasItemMeta() || !stack.getItemMeta().hasEnchants())
            { 
                for(int i = 0; i < enchantments.size(); ++i)
                {
                    stack.addEnchantment(enchantments.get(i), levels.get(i));
                }
            }
        }
    }
    
}
