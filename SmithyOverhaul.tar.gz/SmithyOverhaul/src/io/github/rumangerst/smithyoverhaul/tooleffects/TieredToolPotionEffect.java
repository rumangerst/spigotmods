/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package io.github.rumangerst.smithyoverhaul.tooleffects;

import org.bukkit.entity.Player;
import org.bukkit.potion.Potion;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 * Encapsulates a potion effect
 */
public class TieredToolPotionEffect implements ITieredToolEffect
{

    public PotionEffectType potion;
    public int durationTicks;
    public int strength;

    public TieredToolPotionEffect(PotionEffectType potion, int durationTicks, int strength)
    {
        this.potion = potion;
        this.durationTicks = durationTicks;
        this.strength = strength;
    }

    public TieredToolPotionEffect(PotionEffectType potion, double durationSeconds, int strength)
    {
        this.potion = potion;
        this.durationTicks = (int) (durationSeconds * 1000.0 / 50.0);
        this.strength = strength;
    }

    @Override
    public void applyToPlayer(Player player)
    {
        player.addPotionEffect(new PotionEffect(potion, durationTicks, strength, true, true));
    }
}
