/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package io.github.rumangerst.survivaloverhaul;

import io.github.rumangerst.spigot.nbtapi.SpigotNBT;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;

/**
 *
 * @author ruman
 */
public class SurvivalWaterPotion
{
    SurvivalWater parent;
    public String id;
    public String name;
    public String[] lore;
    public double satisfaction;
    PotionEffect[] effects;
    
    public SurvivalWaterPotion(SurvivalWater parent, String id, String name, String lore, double satisfaction, PotionEffect ... effects)
    {
        this.parent = parent;
        this.id = id;
        this.name = name;
        this.lore = lore.split("\n");
        this.effects = effects;
        this.satisfaction = satisfaction;
    }
    
    public void applyTo(Player player)
    {
        parent.hydratePlayer(player, satisfaction);
        
        for(PotionEffect e : effects)
        {
            player.addPotionEffect(e);
        }
    }
    
    public ItemStack makeStack(int amount, String name, String ... lore)
    {
        ItemStack stack = new ItemStack(Material.POTION, amount);
        SpigotNBT.setString(stack, "display/Name", name);
        SpigotNBT.setStringList(stack, "display/Lore", lore);
        SpigotNBT.setString(stack, "survival_waterid", id);
        
        return stack;
    }
    
    public ItemStack makeStack(int amount)
    {
        return makeStack(amount, name, lore);
    }
}
